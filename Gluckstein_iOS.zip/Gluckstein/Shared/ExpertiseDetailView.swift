//
//  ExpertiseDetailView.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-25.
//

import SwiftUI

struct ExpertiseDetailView: View {
    
    @State var expertise: Expertise
    
    var body: some View {
        WebView(urlToLoad: Bundle.main.url(forResource: expertise.htmlFileName, withExtension: "html")!)
            .navigationTitle(expertise.title)
    }
}

struct ExpertiseDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ExpertiseDetailView(expertise: Expertise(title: "Title", htmlFileName: "page"))
    }
}
