//
//  TeamView.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-13.
//

import SwiftUI

struct OurTeamView: View {
    var body: some View {
        List {
            Section {
                Image("Team")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(.horizontal, -16)
                    .padding(.vertical, -8)
            }
            Section {
                NavigationLink(destination: TeamView(teamName: "Partners", employees: Employee.partners)) {
                    Label("Partners", systemImage: "person.2")
                }
                NavigationLink(destination: TeamView(teamName: "Lawyers", employees: Employee.lawyers)) {
                    Label("Lawyers", systemImage: "briefcase")
                }
                NavigationLink(destination: TeamView(teamName: "Law Clerks/Paralegals", employees: Employee.lawClerksAndParalegals)) {
                    Label("Law Clerks/Paralegals", systemImage: "building.columns")
                }
                NavigationLink(destination: TeamView(teamName: "Medical", employees: Employee.medical)) {
                    Label("Medical", systemImage: "stethoscope")
                }
                NavigationLink(destination: TeamView(teamName: "Client Liaison", employees: Employee.clientLiaison)) {
                    Label("Client Liaison", systemImage: "person.crop.square.fill.and.at.rectangle")
                }
                NavigationLink(destination: TeamView(teamName: "Finance & Operations", employees: Employee.financeAndOperations)) {
                    Label("Finance & Operations", systemImage: "building")
                }
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle("Our Team")
    }
}

struct OurTeamView_Previews: PreviewProvider {
    static var previews: some View {
        OurTeamView()
    }
}
