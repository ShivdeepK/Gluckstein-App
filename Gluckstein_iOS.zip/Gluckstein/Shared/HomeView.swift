//
//  ContentView.swift
//  Shared
//
//  Created by Jayden Irwin on 2020-11-13.
//

import SwiftUI

struct HomeView: View {
    
    @State var showingPDF = false
    @State var pdfURL: URL = Bundle.main.url(forResource: "Manage Your Recovery", withExtension: "pdf")!
    
    var body: some View {
        NavigationView {
            List {
                Section {
                    Image("Logo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(.white)
                        .padding(.vertical, 16)
                        .listRowBackground(Color("Brand"))
                }
                Section {
                    NavigationLink(
                        destination: AboutUsView(),
                        label: {
                            Label("About Us", systemImage: "info.circle")
                        })
                    NavigationLink(
                        destination: LocationsView(),
                        label: {
                            Label("Locations", systemImage: "mappin.and.ellipse")
                        })
                    NavigationLink(
                        destination: OurTeamView(),
                        label: {
                            Label("Our Team", systemImage: "person.3")
                        })
                    NavigationLink(
                        destination: ExpertiseView(),
                        label: {
                            Label("Expertise", systemImage: "briefcase")
                        })
                    Link(destination: URL(string: "https://podcasts.apple.com/podcast/id1522046215")!, label: {
                        Label("Podcast", systemImage: "dot.radiowaves.left.and.right")
                    })
                }
                Section(header: Text("Resources".uppercased())) {
                    Button("Manage Your Recovery", action: {
                        pdfURL = Bundle.main.url(forResource: "Manage Your Recovery", withExtension: "pdf")!
                        showingPDF = true
                    })
                    Button("Child With Special Needs", action: {
                        pdfURL = Bundle.main.url(forResource: "Child With Special Needs", withExtension: "pdf")!
                        showingPDF = true
                    })
                    Button("Neurological Assesments", action: {
                        pdfURL = Bundle.main.url(forResource: "Neurological Assessments", withExtension: "pdf")!
                        showingPDF = true
                    })
                }
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Why Gluckstein")
                            .font(.title)
                        Text("Our team of personal injury lawyers serves clients in Toronto, Ottawa, Niagara, and across Ontario and are here to work with you. Our goal is to help you recover from your injury without the worry of what’s to come and to get you the compensation you deserve. At Gluckstein Lawyers, you can count on us to be your advocates, and you will receive ongoing support, compassion, and, most of all, results. We are on your side during these devastating times, whether you were in a car accident, suffered a brain injury, had a slip-and-fall, or experienced a poor outcome following medical care. Let our personal injury lawyers work with the insurance companies so you don’t have to go through the frustration. While our trusted expertise gets you the legal and medical results you need, we’re also here to just listen.\n\nGluckstein accommodates you, from conducting our meetings in your preferred language to keeping you up to date on all of our progress. Our team welcomes residents from Ontario’s many cities and boroughs. We see our clients like family, and there’s nothing we wouldn’t do for them! So, get on the path to recovery today by calling or emailing Gluckstein’s personal injury lawyers for a free consultation.")
                    }
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Gluckstein")
            .sheet(isPresented: $showingPDF) {
                QuicklookPreviewView(url: self.pdfURL)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
