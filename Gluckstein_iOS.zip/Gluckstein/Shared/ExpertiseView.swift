//
//  ExpertiseView.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-13.
//

import SwiftUI

struct ExpertiseView: View {
    
    let expertises: [Expertise] = [
        Expertise(title: "Car Accidents", htmlFileName: "car"),
        Expertise(title: "Medical Malpractice", htmlFileName: "medical"),
        Expertise(title: "Birth Injury", htmlFileName: "birth"),
        Expertise(title: "Wrongful Death", htmlFileName: "death"),
        Expertise(title: "Brain Injury", htmlFileName: "brain"),
        Expertise(title: "Spinal Injury", htmlFileName: "spinal"),
        Expertise(title: "Long Term Disability", htmlFileName: "disability"),
        Expertise(title: "Slip And Falls", htmlFileName: "slip"),
        Expertise(title: "Product Liability", htmlFileName: "product"),
        Expertise(title: "Class Action/Mass Tort", htmlFileName: "classaction")
    ]
    
    var body: some View {
        List {
            Section {
                Image("Expertise")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(.horizontal, -16)
                    .padding(.vertical, -8)
            }
            Section {
                ForEach(expertises) { expertise in
                    NavigationLink(destination: ExpertiseDetailView(expertise: expertise)) {
                        HStack {
                            Image(expertise.htmlFileName)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 64, height: 64)
                                .cornerRadius(6)
                            Text(expertise.title)
                        }
                    }
                }
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle("Expertise")
    }
}

struct ExpertiseView_Previews: PreviewProvider {
    static var previews: some View {
        ExpertiseView()
    }
}
