//
//  GlucksteinApp.swift
//  Shared
//
//  Created by Jayden Irwin on 2020-11-13.
//

import SwiftUI

@main
struct GlucksteinApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
