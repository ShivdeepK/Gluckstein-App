//
//  TeamView.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-25.
//

import SwiftUI

struct TeamView: View {
    
    let teamName: String
    let employees: [Employee]
    
    var body: some View {
        List {
            ForEach(employees) { (employee) in
                NavigationLink(employee.name, destination: EmployeeView(employee: employee))
            }
        }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle(teamName)
    }
}

struct TeamView_Previews: PreviewProvider {
    static var previews: some View {
        TeamView(teamName: "Lawyers", employees: [])
    }
}
