//
//  EmployeeView.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-25.
//

import SwiftUI

struct EmployeeView: View {
    
    let employee: Employee
    
    var body: some View {
        ScrollView {
            Text(employee.bio)
                .padding()
        }
            .navigationTitle(employee.name)
    }
}

struct EmployeeView_Previews: PreviewProvider {
    static var previews: some View {
        EmployeeView(employee: Employee(name: "Bob", bio: "He is good."))
    }
}
