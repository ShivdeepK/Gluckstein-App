//
//  WebView.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-12-15.
//

import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    
    var urlToLoad: URL
    
    init(urlToLoad: URL) {
        self.urlToLoad = urlToLoad
    }
    
    func makeUIView(context: Context) -> WKWebView  {
        let config = WKWebViewConfiguration()
        config.ignoresViewportScaleLimits = false
        config.applicationNameForUserAgent = "Gluckstein"
        let view = WKWebView(frame: .zero, configuration: config)
        view.navigationDelegate = context.coordinator
        view.allowsLinkPreview = false
        view.backgroundColor = UIColor.systemBackground
        view.isOpaque = false
        view.load(URLRequest(url: urlToLoad))
        return view
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        //
    }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(self)
    }
    
    class Coordinator: NSObject, WKNavigationDelegate {
        
        var parent: WebView
        
        init(_ parent: WebView) {
            self.parent = parent
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            webView.scrollView.showsHorizontalScrollIndicator = false
        }
        
    }
    
}
