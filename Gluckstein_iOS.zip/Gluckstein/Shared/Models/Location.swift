//
//  Location.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-25.
//

import CoreLocation

struct Location: Identifiable {
    
    let name: String
    var id: String {
        name
    }
    let coordinate: CLLocationCoordinate2D
    let phoneNumber: Int
    
}
