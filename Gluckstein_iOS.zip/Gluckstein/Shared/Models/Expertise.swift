//
//  Expertise.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-25.
//

import Foundation

struct Expertise: Identifiable {
    
    let title: String
    var id: String {
        title
    }
    let htmlFileName: String
    
}
