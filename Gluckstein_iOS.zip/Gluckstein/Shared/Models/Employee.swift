//
//  Employee.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-25.
//

import Foundation

struct Employee: Identifiable {
    
    static let partners = [
        Employee(name: "Bernard L. Gluckstein", bio: """
            Bernard has always been a staunch advocate for the rights of injured persons. Well-known for his philanthropy, he provides executive and financial support to many non-profit organizations across Ontario. He frequently organizes events for persons with brain and spinal cord injuries.

            Bernard has 57 years of experience in Personal Injury litigation and is a Lifetime Member of the Law Society of Ontario.

            Within the firm, Bernard is personally involved in most of the serious cases as well as taking an advisory position on most other cases, by providing insight and ensuring each client receives maximum compensation structured according to the specific needs of the client.

            He has lectured extensively to various medical, legal, insurance and rehabilitation groups throughout North America. He is also widely published, including co-editing LexisNexis’ Personal Injury Practice Manual.
            """),
        Employee(name: "Charles E. Gluckstein", bio: "Charles advocates for results that achieve maximum recovery of lifestyle for each one of his clients. Charles is a Specialist in Civil Litigation which encompasses personal injury, motor vehicle claims, medical and professional negligence, as well as occupier’s liability issues. Charles commands a thorough knowledge of all relevant Automobile Legislation, providing trusted experience for all aspects of dispute resolution.")
    ]
    static let lawyers = [
        Employee(name: "Derek Nicholson", bio: """
            Derek Nicholson has been one of Ottawa’s leading Civil Trial Lawyers since 1980. In his early years of practice, he focused on Defense Insurance work represented several major insurance companies, including Chubb Insurance and Royal Insurance. He has also represented many high-profile clients, including the Attorney General of Canada in a trial against Boeing USA, CJOH -TV and Blue Line Taxi.

            In the last forty years, he has focused on Personal Injury work, especially in Catastrophic Injury victims (including those affected by traumatic brain injuries, spinal cord injuries and multiple injuries resulting in a 55% whole body impairment as defined under the Insurance legislation.)

            With Derek as a key member of Gluckstein Lawyers and lead lawyer of our new Ottawa location, Nicholson Gluckstein Lawyers continues to take on the most complex personal injury claims throughout Ontario. His approach and focus are on helping injured victims recover. He has guided hundreds of Plaintiffs through recovery by assisting in maximizing rehabilitation benefits and supporting victims to restructure their lives.

            Although he now exclusively represents Plaintiffs against Insurance companies, it is of great value that he represented insurance companies in the early years to obtain insight to assist Plaintiffs today.

            Derek Nicholson has also co-chaired a program on the recent changes to the Statutory Accident Benefits for Ottawa’s Bar Association (the Carleton County Law Association) in the Fall of 2010. He has done demonstrations of Cross-Examinations of Bio-Mechanical Engineering experts before 400 lawyers at the OTLA Fall 2015 Conference.

            Derek served on the Executive of the Ontario Trial Lawyers Association as Treasurer and Regional Organization Coordinator. Derek was initially elected a Director of the Ontario Trial Lawyers Association. He is the former Chair of the OTLA cup committee, which organizes an annual Moot Court in personal injury for six of the law schools in Ontario. Derek is also a member of the American Association for Justice.

            Derek recently secured the largest settlement in Canadian History. He won over $15 million for clients who were catastrophically injured in a motor vehicle accident. The settlement also produced one of the most significant structured settlements in Canadian History of $11 million.
            """),
        Employee(name: "Richard Halpern", bio: """
            Richard Halpern is a senior lawyer acting exclusively for injured people in medical negligence cases, with a special focus on infants injured at or around the time of birth.  Richard is known across Canada for his expertise in birth injury cases.  He has more than 30 years of experience representing seriously injured people.

            Richard has a detailed understanding of the highly technical medical issues, particularly relating to birth injury cases.  His experience allows him to provide meaningful advice and direction to families considering a medical negligence lawsuit following a review of the medical record.

            Richard is known for tackling some of the most complex and challenging medical malpractice cases.  He has lectured and written extensively on matters concerned with obstetrics, the cause of newborn injury, medical malpractice cases more generally, and legal and trial strategies.  He has delivered more than 80 presentations to professional groups.  One of his more recent papers is titled “Birth Trauma Litigation: Proving the Cause of Newborn Neurologic Injury”.

            In 2015, Richard was the recipient of the Award for Distinguished Service to the legal profession, conferred by his peers at the Ontario Bar Association.  Richard has been recognized by and listed in The Best Lawyers™ in Canada.  He has been recognized in The Canadian Legal Lexpert® Directory.

            Richard has acted in hundreds of medical malpractice cases.  He has achieved significant settlements for his clients, many exceeding $10,000,000, though past results are not necessarily indicative of future outcomes.  He has appeared in the Superior Court of Ontario and the Ontario Court of Appeal.

            Richard is currently a member of The Holland Group, a group that promotes reforms in medical malpractice cases aimed at increasing access to justice and timely and equitable resolutions of medical malpractice claims.  The Holland Group is chaired by former Ontario Court of Appeal Justice John Laskin.  Richard is also a member of a bench a bar committee established by the Ontario Court of Justice.  The members of this committee included judges and senior lawyers and the committee meets to look at reforms to improve the administration of justice.

            Richard is a past President of the Ontario Trial Lawyers Association.  He is a past member of the Judicial Advisory Committee on Judicial Appointments (GTA) appointed by the Federal Minister of Justice.  This committee evaluated candidates for appointment to the Superior Court of Justice, the Ontario Court of Appeal, the Federal Court and the Federal Court of Appeal.

            In addition to his Bachelor of Arts degree (BA) and Bachelor of Laws degree (LLB), Richard earned a Masters Degree in Law (LLM) in Civil Litigation at Osgoode Hall Law School.  He is a member of the Advocates’ Society, the Ontario Trial Lawyers’ Association, the Ontario Bar Association and the American Association of Justice.
            """),
        Employee(name: "David Lackman", bio: """
            David graduated with Honours from Montreal’s McGill University in 1978. He next received his Juris Doctorate degree, cum laude, from Southwestern University School of Law in Los Angeles. In 1982 he was admitted by the Supreme Court of California to practice as an Attorney and Counsellor-at-Law in the courts of California. After receiving his Certificate of Qualification through the University of Ottawa Faculty of Law, in 1985 David was admitted by the Law Society of Ontario as a Barrister, Solicitor and Notary Public.

            His litigation practice now extends over 30 years, encompassing serious and complex personal injury and disability claims, wrongful death claims, criminal injuries compensation, and proceedings before the Financial Services Commission and Pension Appeals Board. David has achieved outstanding results in personal injury claims against some of the country’s largest corporations, including railways.
            """),
        Employee(name: "Sandev Purewal", bio: """
            Sandev was called to the Ontario Bar in 2001 and is an experienced lawyer in the areas of serious personal injury and disability insurance, while also having addressed a wide range of civil and commercial litigation matters. The Law Society of Ontario (LSO) certified him as a Specialist in Civil Litigation in 2017. He has appeared as counsel before the Superior Court of Justice, Ontario Court of Appeal, Financial Services Commission of Ontario and the Tax Court of Canada.

            Sandev is currently a member of the OTLA Board of Directors (2015-date), Past-President (2010-2013) and Director (2007-2009) of the Brain Injury Association of Peel & Halton (BIAPH), as well as being actively involved in other community activities, such as leading the “Helmets on Kids” project in the Peel Region since 2007, which provides free bicycle helmets to children in need.

            Since 2010, Sandev has been a Senior Litigation Lawyer at the leading Toronto law firm of Gluckstein Lawyers P.C.

            He received his Bachelor of Arts (Honours) and Bachelor of Education degrees from York University in 1996, a Certificate in Dispute Resolution from the University of Toronto in 1998, and his J.D. from Osgoode Hall Law School in 1999. While attending Osgoode Hall Law School, Sandev was also a Research Assistant to Professor D. Paul Emond in 1998, and helped to develop the Professional Development Program’s Negotiation Skills Workshop.

            Sandev has published several papers—in the areas of personal injury, disability insurance and civil litigation—and presented at various forums to further lawyers’ continuing legal education.
            """),
        Employee(name: "Ryan Breedon", bio: """
            Called to the Bar in 2004, Ryan practised at a leading litigation firm for over a decade, joining the partnership in 2014. During this time, his practice was divided between representing doctors in medical malpractice and discipline cases, and a wide variety of commercial litigation, acting for individuals, multinational corporations, governments and everyone in between.

            In 2017, Ryan founded his own firm in Barrie, Ontario. He represents patients in medical malpractice case. Ryan acts as trial counsel for Gluckstein Personal Injury Lawyers in serious medical malpractice cases.

            Ryan has taken all sorts of cases to trial. He has tried cases before judges, juries, arbitrators and administrative panels all over Ontario. Breedon Litigation maintains a list of reported decisions in which Ryan appeared as counsel.

            Ryan has been repeatedly recommended by other lawyers and is regularly retained by other lawyers to conduct trials on behalf of their clients. Ryan is a Board member and the Chair of the Medical Malpractice section of the Ontario Trial Lawyers’ Association. He teaches trial advocacy at Osgoode Hall Law School and the Intensive Trial Advocacy Workshop, and regularly speaks and writes on a wide range of topics. He is often asked to give presentations to lawyers, doctors, and other professionals.
            """),
        Employee(name: "Jonathan Burton", bio: """
            Jonathan joined the firm in 2005. He received his Bachelor of Laws degree from the University of Western Ontario in June 2006, and returned to the firm to carry out his articles-at-law. Following his call to the Ontario Bar in June 2007, Jonathan assumed his current position of associate lawyer at Gluckstein Lawyers. Jonathan restricts his practice to insurance litigation including Personal Injury, disability matters, occupier’s liability, medical malpractice and product liability.

            Jonathan has always been driven by a passion to help those in need, which fuelled his decision to pursue a legal career representing injured persons and their families. Prior to commencing his legal studies, in 2003 Jonathan attained a Bachelor of Administrative and Commercial Studies degree in Organizational and Human Resources, also at the University of Western Ontario. He has an outstanding ability to communicate with and understand his clients and their needs.
            """),
        Employee(name: "Jan Marin", bio: """
            Jan received her Bachelor of Arts (Honors) in Development Studies from Huron University College at the University of Western Ontario in 2005 and her J.D. from Western’s Law School in 2009. While attending law school, Jan volunteered with the school’s Community Legal Clinic and Pro-Bono Students Canada. She also participated in an international exchange program at ESADE in Barcelona where she studied both International and European Union law. Jan was called to the bar in June 2010.

            Jan’s Personal Injury practice is focused on medical malpractice and professional liability.

            Jan is a passionate advocate for her clients and their families. When not practicing law, Jan enjoys travelling, playing soccer or volleyball and spending time with her husband and two children.
            """),
        Employee(name: "Jordan Assaraf", bio: """
            Jordan joined the Gluckstein team in 2012 to carry out his articles-at-law. He graduated from York University in 2007. He received his Juris Doctorate degree from Bond University in Australia and completed his Canadian Accreditation in 2012. Following his call to the bar in 2013, Jordan assumed his current position of associate lawyer at Gluckstein Lawyers. Jordan’s practice is devoted to all areas of Personal Injury litigation on behalf of plaintiffs, including motor vehicle accident claims, class action and mass tort litigation, occupier’s liability claims, product liability claims, medical malpractice and accident benefit claims.
            """),
        Employee(name: "Danielle Bartlett", bio: """
            Danielle Bartlett is a key member of the Nicholson Gluckstein Lawyers team and working alongside Derek Nicholson to head up our new Ottawa location on complex personal injury claims. Since her call to the bar in 2017, she has practiced primarily in the areas of personal injury and insurance law, representing clients recovering from various types of catastrophic injuries. She has appeared before Ontario tribunals, the Small Claims Court and the Ontario Superior Court of Justice.

            Danielle maintains a compassionate “client first” approach to her practice as she is privileged to be able to assist people through their rehabilitation and ensure they are fairly compensated. She is also passionate about advocacy for survivors of institutional sexual abuse who wish to pursue their claims through civil actions.

            In her spare time, Danielle enjoys yoga, cooking and travelling.
            """),
        Employee(name: "Jessica Golosky", bio: """
            Jessica joined Gluckstein Lawyers as an articling student in 2017 and is a graduate of the J.D. program from the Faculty of Law at Western University. She graduated on the Dean’s Honour List and was awarded the Law Society of Ontario Prize for academic excellence.

            As a law student, Jessica worked as a Research Student for Professor Richard H. McLaren and contributed to various corporate and commercial publications. Throughout her time in law school, she was actively involved in the Western Journal of Legal Studies as both a Managing Editor and Senior Editor and volunteered as an Associate Caseworker with the Family Law Team at Western’s Community Legal Services clinic.  She also participated in an exchange program during her final year of law school at Stockholm University.

            Prior to law school, Jessica graduated from the University of Toronto with an Honours Bachelor of Science degree with High Distinction in the areas of Psychology, Sociology, and Urban Studies.
            """),
        Employee(name: "Gabriel Lessard", bio: """
            Gabriel joined Gluckstein Lawyers as an articling student in 2017 and is a graduate of the J.D. program from the Faculty of Law at Queen’s University.

            As a law student, Gabriel volunteered at the Concordia Student Union Legal Information Clinic where he provided legal information to Concordia undergraduate students. He was also significantly involved at the Queen’s Legal Aid Clinic. As a student caseworker at Queen’s Legal Aid, Gabriel represented clients at the Landlord and Tenant Board, the Social Benefits Tribunal and the Criminal Injuries Compensation Board. Gabriel also volunteered as a group leader where he trained and supervised 10 volunteer student caseworkers.
            """)
    ]
    static let lawClerksAndParalegals = [
        Employee(name: "Barb Andrews", bio: """
            Barbi has been with Gluckstein Lawyers since 2001 working within the accident benefits department advocating for client’s benefits. Barbi has 18 years of experience administering Personal Injury claims. She is a licensed paralegal with the Law Society of Ontario.

            Prior to working in Personal Injury law, Barbi was a teacher at George Brown College and a private business college. She obtained a B.Sc. at the University of Toronto and B.Mus. at Brigham Young University, Utah, USA.

            She has participated in numerous conferences as a guest speaker and was Co-Chairperson of the 2012 Spring Conference. In September 2015, Barbi was honoured with the OTLA Distinguished Law Clerk Award which is awarded to a senior law clerk who has consistently exemplified the mission of the organization.

            Barbi is involved in various volunteer programs with the Native Canadian community and also conducts motivational seminars and speeches. In 2018, Barbi was the recipient of the Hilda Goulding Award.

            Barbi is presently attending Ryerson University on a part-time basis within the Occupational Health and Safety Management Degree Program. She graduated from the University of Toronto, Theology Degree Program in 2012 and is an ordained Minister.
            """),
        Employee(name: "Janet Lebeau", bio: """
            Over 23 years experience as a law clerk specializing in personal injury particularly medical negligence matters.  Over 18 years operated an independent litigation support business. A graduate of McMaster University (BA) and York University (B.Ed).

            Janet is involved in all aspects of a medical negligence matter, from organizing, collating and analyzing medical records; preparing chronologies;  locating, retaining and briefing the appropriate expert; coordinating evidence; interviewing witnesses; and preparing documents such as statements of claim, pre-trial memorandums and mediation memorandums; as well as assisting at trial.

            She is known for developing a rapport with clients by treating them with empathy and compassion.
            """),
        Employee(name: "Alison O’Callaghan", bio: """
            Alison joined the Gluckstein Lawyers team in 2012. She brings more than 10 years of experience working in the Statutory Accident Benefits field and has experience working on both plaintiff and insurance sides.

            At Gluckstein she works alongside the lawyers as a law clerk with specialized knowledge of the SABS.  Alison is passionate about supporting her clients in order to maintain benefits that assist in their recovery.  She has been extensively involved in advocating for ongoing benefits for clients through the Licence Appeal Tribunal – AABS resolution process.
            """),
        Employee(name: "Jane Lou", bio: """
            Jane Lou joined the Gluckstein Lawyers team in early 2016, bringing with her over ten years of experience in the legal, marketing and customer service fields.

            Prior to joining the firm, Jane had been in private practice, owning and operating a successful immigration and paralegal service. Jane is a paralegal licensed by the Law Society of Ontario (LSO), an immigration consultant certified by the Immigration Consultants of Canada Regulatory Council (ICCRC), and a member of the Financial Services Commission of Ontario (FSCO).

            Before immigrating to Canada, Jane obtained two Bachelor’s degrees with Honours at Zhejiang University and Beijing University, respectively. She had worked as a television producer, director and writer with a Chinese state-owned television station. Her works (live shows and documentaries) have won numerous local, provincial and national awards.

            Jane’s ability to speak both Mandarin and Cantonese allows her to build and maintain a strong and trust-based relationship with other members of the Chinese community, and with clients requiring legal assistance when unfortunate accidents occur.

            Jane is actively involved in the Chinese community and devotes considerable time and expertise to pro bono work. She also sits on the board of several non-profit organizations.

            Jane is a frequent writer of articles for the Chinese media, and has been called upon to provide her insights and commentary for Canada’s national media when immigration policy is reviewed or modified by the Federal and Provincial Governments.
            """),
        Employee(name: "Vida Atefy", bio: """
            Vida joined the Gluckstein Lawyers team in 2014. She brings over nine years of personal injury experience in her role as a licensed Paralegal/Law Clerk at Gluckstein Lawyers. She is a Licensed Paralegal with the Law Society of Ontario. She has knowledge of Rules of Civil Procedure, Provincial Insurance Act, Statutory Accident Benefits Schedule and Dispute Resolution Legislation.

            Vida has extensive legal experience successfully providing legal services as a Licensed Paralegal, representing clients in complex Personal Injury and disability related matters before the Financial Services Commission of Ontario, mediating, arbitrating and settling disputes. She also has experience before the Safety, Licensing Appeals and Standards Tribunals Ontario – AABS, conducting case conferences and hearings.

            Vida maintains a strong client relationship. She is passionate about advocating for clients to ensure they receive the necessary medical support and the maximum compensation in the process of their recovery.
            """),
        Employee(name: "Roger Shoreman", bio: """
            Roger brings more than 30 years of experience to his role as Senior Law Clerk at Gluckstein Lawyers. He has qualified as a Fellow of both the Institute of Law Clerks of Ontario and the Institute of Legal Executives UK, earning fellowship certification in Contract Law, Torts, Criminal Law, e-discovery, and project management. He has taught the Institute of Law Clerks Civil Litigation program.

            In 2016, he was honoured with the OTLA Distinguished Law Clerk Award which is awarded to a senior law clerk who has consistently exemplified the mission of the organization.

            Roger is dedicated to enhancing client’s cases through his preparatory skills and experience.

            Roger has worked both for Defence firms representing Physicians in Ontario, and for almost ten years he assisted a number of leading Plaintiff’s Counsel while he operated his own freelance litigation support business.

            Roger believes in treating clients with respect and empathy, and opposing Counsel and their staff with professional courtesy and integrity.
            """),
        Employee(name: "Kavinah Ravinthiran", bio: """
            Kavinah joined the Gluckstein team in April 2019. She brings her experience in civil litigation and has experience working on both plaintiff and defendant sides.

            She is passionate about human rights, and in particular, advocating for inter-sectional minorities. Her parents emigrated from Sri Lanka about 30 years ago, and she was born and raised in the Toronto area. As a first generation child, she is able to understand the needs of immigrants effortlessly. She is known for treating clients with compassion and care.

            She moved to England to complete her LLB, and plans on pursuing her career as a lawyer in Ontario. When she is not working, she enjoys spending time with her family and friends, as well as going to the gym and watching South Asian films.
            """)
    ]
    static let clientLiaison = [
        Employee(name: "Brenda Agnew", bio: """
            Brenda is the proud mother of two boys, Chase and Maclain. Her son Maclain has severe Cerebral Palsy and profound hearing loss as a result of a condition known as Kernicterus, a brain injury that results from untreated jaundice. As a former Gluckstein client herself, Brenda acts as our Client Liaison to support and advise our clients and their families throughout their case.

            She tirelessly advocates for better systems and programs for children with special needs. Brenda has been appointed to the Community Council for the American Academy of Cerebral Palsy and Developmental Medicine for a 3-year term and is an active member for volunteer organizations such as CP-Net, CHILD-BRIGHT Citizen Engagement Committee, and the Burlington Accessibility Advisory Committee.
            """),
        Employee(name: "Vafa Nematy", bio: """
            In January 2014, Vafa joined Gluckstein Lawyers as a Law Clerk and Client Liaison to the Persian Community for the firm. She brings a decade of Personal Injury law clerk experience earned from her previous employment within a well-established multi-disciplinary Ontario law firm.

            As a Law Clerk, Vafa handles many aspects of a client file – from opening a new file to arriving at the settlement while under the assigned lawyer’s supervision. The added benefit of speaking in Farsi allows Vafa to create and maintain strong relationships with Persian clients by speaking to them in their own language; to listen to their concerns and be able to make appropriate decisions with the lawyer on their files.

            Vafa enjoys meeting with clients both inside and out of the office; keeping clients updated; and, gaining their trust by developing long-term relationships with them. She actively attends community events to expand her network contacts as a referral source to the firm and to staying involved within the community.
            """)
    ]
    static let medical = [
        Employee(name: "Dianne Henderson", bio: """
            Dianne received her nurses training at the Mack School of Nursing. She attended Brock University for her Bachelor of Arts in Psychology and her Masters of Education. Experience in a wide variety of clinical and nursing settings gives Dianne a rich knowledge base that allows her an understanding of the severity of the injuries that our clients face.

            Her role as the Executive Director of the Brain Injury Association of Niagara for six years gives her the advocacy skills that are required as a Medical Consultant to Gluckstein Lawyers. The additional services that Dianne provides to the clients of Gluckstein Lawyers are unique to this firm. Beyond the legal expertise in our office, Dianne offers medical insight that assists the lawyers to understand the degree of disability and impairment. Her knowledge is particularly supportive in “catastrophic determination”.

            Among her various commitments, Dianne was a Member of the Board to Headway Homes, a non-profit organization that intended to provide residence and services for severely brain-injured individuals. She was a committee member to Brain Injury Awareness Month (BIAM).

            Dianne is also an instructor for the “Brain Injury Training Program” offered to Registered Nursing Staff and Community Support Workers across Ontario. She co-ordinates conferences, some of which include “Compassion Fatigue”, “Seize The Day” and “From Hospital to Home” and the Toronto Collaborative Neurosciences Symposium. Dianne is continuously asked to share her knowledge and expertise at various conferences and clinics.
            """),
        Employee(name: "Lynn Parker", bio: """
            Lynn Parker joined Gluckstein Lawyers as an accomplished professional with extensive insurance experience. Her most recent role was an Insurance Consultant, where she was closely working with legal counsel on both Statutory Accident Benefits (SABS) and tort. With over thirty-five years of experience in Litigation Management, Claims Resolution and Claims Management, Lynn served in many roles, including management roles in Head Office Claims.

            Lynn completed her certification in Life Care Planning through the Intellicus/University of Florida. She was instrumental in developing the first Canadian program for Certification in Life Care Planning.
            """)
    ]
    static let financeAndOperations = [
        Employee(name: "Terri Robins", bio: "")
    ]
    
    let id = UUID()
    let name: String
    let bio: String
    
}
