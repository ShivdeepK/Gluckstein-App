//
//  LocationView.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-25.
//

import SwiftUI
import MapKit

struct LocationView: View {
    
    let location: Location
    
    var body: some View {
        Map(coordinateRegion: .constant(MKCoordinateRegion(center: location.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.25, longitudeDelta: 0.25))), interactionModes: [], showsUserLocation: false, annotationItems: [location]) { location in
            MapPin(coordinate: location.coordinate)
        }
        .overlay(HStack {
            Link("Call Us", destination: URL(string: "tel:\(location.phoneNumber)")!)
                .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                .background(Color(UIColor.secondarySystemBackground))
                .cornerRadius(8)
                .padding()
        }, alignment: .bottom)
            .navigationTitle(location.name)
            .navigationBarTitleDisplayMode(.inline)
    }
}

struct LocationView_Previews: PreviewProvider {
    static var previews: some View {
        LocationView(location: Location(name: "Toronto", coordinate: CLLocationCoordinate2D(latitude: 0.0, longitude: 0.0), phoneNumber: 0))
    }
}
