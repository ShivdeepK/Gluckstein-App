//
//  QuicklookPreviewView.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-12-15.
//

import SwiftUI
import QuickLook

struct QuicklookPreviewView: UIViewControllerRepresentable {
    
    var url: URL
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func updateUIViewController(_ viewController: UINavigationController, context: UIViewControllerRepresentableContext<QuicklookPreviewView>) {
        if let controller = viewController.topViewController as? QLPreviewController {
            controller.reloadData()
        }
    }
    
    func makeUIViewController(context: Context) -> UINavigationController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        controller.reloadData()
        return UINavigationController(rootViewController: controller)
    }
    
    class Coordinator: NSObject, QLPreviewControllerDataSource {
        var parent: QuicklookPreviewView
        
        init(_ qlPreviewController: QuicklookPreviewView) {
            self.parent = qlPreviewController
            super.init()
        }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
            return 1
        }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            return self.parent.url as QLPreviewItem
        }
        
    }
}
