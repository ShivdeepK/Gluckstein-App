//
//  AboutUsView.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-13.
//

import SwiftUI

struct AboutUsView: View {
    var body: some View {
        ScrollView {
            Image("About")
                .resizable()
                .aspectRatio(contentMode: .fit)
            Text("At Gluckstein Lawyers, our clients come first. When you’ve been hurt in an accident, looking ahead can be difficult. It is important to find professionals to stand by you, uplift you, and guide you through each and every obstacle ahead. Gluckstein offers the gentle touch and compassion your family needs when faced with life-altering injuries.\n\nSince 1962, we have helped clients move forward with dignity, respect and trusted experience. Celebrated as pioneers in our field, Gluckstein Lawyers is an award-winning industry leader in neuro-trauma (brain injuries), spinal cord injuries and serious orthopaedic injuries.\n\nGluckstein is dedicated to supporting and empowering non-profit organizations and causes within our community, at times pioneered by our former clients. Giving back is incredibly important to us– for this reason, we regularly sponsor annual conferences, symposia and social events for associations and foundations connected with the medical and disabled community.\n\nWith a medical specialist on staff, Gluckstein stands with our clients beyond their settlement, by helping them acclimate to their new circumstances.")
                .padding()
        }
        .navigationTitle("About Us")
    }
}

struct AboutUsView_Previews: PreviewProvider {
    static var previews: some View {
        AboutUsView()
    }
}
