//
//  LocationsView.swift
//  Gluckstein
//
//  Created by Jayden Irwin on 2020-11-13.
//

import SwiftUI
import CoreLocation

struct LocationsView: View {
    
    let locations = [
        Location(name: "Toronto", coordinate: CLLocationCoordinate2D(latitude: 43.64913370470648, longitude: -79.38042378635639), phoneNumber: 14164084252),
        Location(name: "Ottawa", coordinate: CLLocationCoordinate2D(latitude: 45.41318004723082, longitude: -75.6896655433863), phoneNumber: 16132413400),
        Location(name: "Niagara", coordinate: CLLocationCoordinate2D(latitude: 43.11367413014882, longitude: -79.24220347830259), phoneNumber: 19052286169)
    ]
    
    var body: some View {
        List {
            ForEach(locations) { (location) in
                NavigationLink(location.name, destination: LocationView(location: location))
            }
        }
        .listStyle(InsetGroupedListStyle())
        .navigationTitle("Locations")
    }
}

struct LocationsView_Previews: PreviewProvider {
    static var previews: some View {
        LocationsView()
    }
}
